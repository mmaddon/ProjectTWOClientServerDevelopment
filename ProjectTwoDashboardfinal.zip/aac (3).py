from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    # Constructor!!!!!!!!!!!!!!!!!!!!!!!!!
    def __init__(self, username, password, port):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        print('Creating new object!')
        self.client = MongoClient('mongodb://%s:%s@localhost:%s' % (username, password, port))
        self.database = self.client['AAC']

# Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            result = self.database.animals.insert_one(data)  # data should be dictionary 
            return "success: "+ result.acknowledged
        else:
            raise Exception("Nothing to save, because data parameter is empty")
        return False

    def read(self, query):
        print("reading from bb")
        try:
            #return self.database.animals.find_one(query) 
            return self.database.animals.find(query) 
        except Exception as e:
            return e
        return False
        
    def updateA(self,query,data):
        if data is not None:
            result = self.database.animals.update_one(query,data)  # data should be dictionary 
            return "success" + result.acknowledged
        else:
            raise Exception("Nothing to save, because data parameter is empty")
        return False
    
    def deleteA(self, data):
        if data is not None:
            result = self.database.animals.delete_one(data)  # data should be dictionary 
            return "success" + result.acknowledged
        else:
            raise Exception("Nothing to save, because data parameter is empty")
        return False
    
    
